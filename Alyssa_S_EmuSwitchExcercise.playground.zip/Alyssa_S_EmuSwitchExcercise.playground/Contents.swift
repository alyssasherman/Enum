import UIKit

//Bread
enum Bread {
    case White
    case Wheat
    case Itlaian
    case Garlic
}
var BreadChoice = Bread.White

//Meat
enum Meat {
    case turkey
    case tuna
    case chicken
    case ham
}

var MeatChoice = Meat.turkey

//Cheese
enum Cheese {
    case american
    case swiss
    case pepperJack
    case chedder
}

var CheeseCoice = Cheese.american

//veggie
enum Veggie {
    case lettuce
    case spinach
    case peppers
    case pickles
}

var VeggieChoice = Veggie.lettuce

//condiments
enum Condiments {
    case ketcup
    case mayo
    case mustard
}

var CondimentsChoice = Condiments.mayo


switch BreadChoice {
case .Garlic:
    print("you have chosen Garlic bread")
case .White:
    print("you have chosen White bread")
case .Wheat:
    print("you have chosen Wheat Bread")
case .Itlaian:
    print("you have chosen Itlaian Bread")
}


switch MeatChoice {
case .turkey:
    print("you have chosen turkey")
case .tuna:
    print("you have chosen tuna")
case .chicken:
    print("you have chosen chicken")
case .ham:
    print("you have chosen ham")
}


switch CheeseCoice {
case .american:
    print("you have chosen american cheese")
case .swiss:
    print("you have chosen swiss cheese")
case .pepperJack:
    print("you have chosen pepperJack")
case .chedder:
    print("you have chosen chedder cheese")
}


switch CondimentsChoice {
case .ketcup:
    print("you have chosen ketcup")
case .mayo:
    print("you have chosen mayo")
case .mustard:
    print("you have chosen mustard")
}


switch VeggieChoice {
case .lettuce:
    print("you have chosen lettuce")
case .spinach:
    print("you have chosen spinach")
case .peppers:
    print("you have chosen peppers")
case .pickles:
    print("you have pickles")
}

print("have a good day and enjoy!!")
